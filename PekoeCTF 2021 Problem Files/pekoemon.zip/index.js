const express = require('express');
const app = express();
const PORT = process.env.PORT || 8000;

app.use(express.static('public'));

app.set('view engine', 'pug');
app.set('views', './views');

let getPekoemon = () => {
    let pekoeNum = Math.floor(Math.random()*5);
    let pekoeName = '';
    switch(pekoeNum){
        case 0:
            return 'michael';
        case 1:
            return 'lenny';
        case 2:
            return 'harold';
        case 3:
            return 'shrek';
        case 4:
            return 'doge';
        default:
            return;
    }
};

app.get('/', (req, res) => {
    let pekoeNum = Math.floor(Math.random()*5);
    res.render('index', {
        message: '',
        pekoemonName: getPekoemon()
    });
});

app.post('/', (req, res) => {
    let success = Math.random()>0.5;
    res.set('flag', 'pekoe{refresher_mint_bab305}').render('index', {
        message: success ? 'caught' : 'not caught',
        pekoemonName: getPekoemon()
    });
});

app.listen(PORT, () => {
    console.log(`Running on port ${PORT}`);
});

