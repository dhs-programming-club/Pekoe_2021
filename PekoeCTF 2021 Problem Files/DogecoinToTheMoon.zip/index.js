let express = require('express');
let cookieParser = require('cookie-parser');
let app = express();
let PORT = 8000 || process.env.PORT;

app.use(express.static('public'));
app.use(cookieParser());

app.set('view engine', 'pug');
app.set('views', './views');

app.get('/', (req, res) => {
    if(req.cookies['important-information'] === undefined){
        res.cookie('important-information', 'e2RvZ2Vjb2luLXRhcmdldDogIiQxIn0');
    }
    else if(req.cookies['important-information'] === 'e2RvZ2Vjb2luLXRhcmdldDogIm1vb24ifQ==' || req.cookies['important-information'] === 'e2RvZ2Vjb2luLXRhcmdldDogInRoZSBtb29uIn0='){
        res.cookie('flag', 'orange_50b3c2');
    }
    else{}
    res.render('index');
});

app.listen(
    PORT,
    () => {
        console.log(`Running on port ${PORT}`);
    }
);