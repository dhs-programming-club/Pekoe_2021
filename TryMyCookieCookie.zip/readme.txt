To run this problem, you're going to need to have nodejs installed on your PC, which you can find here: https://nodejs.org/en/download/
once you've done that, open terminal or command prompt to this directory & enter node index.js
Lastly, open up your browser and go to localhost:8000
This problem also only works on firefox if you're running it locally