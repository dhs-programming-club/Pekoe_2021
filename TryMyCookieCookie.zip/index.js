let express = require('express');
let cookieParser = require('cookie-parser');
let app = express();
let PORT = 8000 || process.env.PORT;

app.use(express.static('public'));
app.use(cookieParser());

app.set('view engine', 'pug');
app.set('views', './views');

app.get('/', (req, res) => {
    res.cookie('flag', 'chamomile_dba943');
    res.render('index');
});

app.listen(
    PORT,
    () => {
        console.log(`Running on port ${PORT}`);
    }
);