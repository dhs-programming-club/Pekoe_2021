class Main {
  public static void main(String[] args) {
    int input = ????????; //clear this value after recording the output
    int temp = input;
    int output = 0;
    for (int x = 0; x < 3; x++){
     output = temp;
     output = output/2;
     output = output - 5;
     temp = output;
    }

    if (input > temp) {
      output = temp;
      output = output*7;
      temp = output;
    }

    if (output == 0) {
      temp = input%5;
      output = output+temp;
    }

    if (output==temp){
      temp = input/5;
      output = output + temp;

    }
    System.out.println(output);
  }
}

