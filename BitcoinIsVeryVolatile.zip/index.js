let express = require('express');
let app = express();
let PORT = 8000 || process.env.PORT;

app.use(express.static('public'));

app.set('view engine', 'pug');
app.set('views', './views');

app.get('/', (req, res) => {
    res.render('index');
});

app.get('/flag', (req, res) => {
    res.send('right idea, wrong route');
});

app.post('/flag', (req, res) => {
    res.send('right idea, wrong route');
});

app.get('/is-bitcoin-volatile', (req, res) => {
    res.send(true);
});

app.post('/is-bitcoin-volatile', (req, res) => {
    res.send('pekoe{passionfruit_mango_b5048e}');
});

app.listen(
    PORT,
    () => {
        console.log(`Running on port ${PORT}`);
    }
);