
/*
"Whenever the price of bitcoin drops below a certain value
it's no longer efficient to mine. When it comes back up it is."
 - Bertram Gilfoyle
*/

const noLongerProfitableToMine = async () => {
    setTimeout(() => {
        let alert = document.getElementById("alert");
        alert.muted = false;
        alert.play();
        noLongerProfitableToMine();
    }, Math.random()*10000);
};

noLongerProfitableToMine();

var xhttp = new XMLHttpRequest();
xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
        if(xhttp.responseText == 'true'){
            console.log('Bitcoin is very volatile today');
        }
        else{
            console.log(xhttp.responseText);
        }
       
    }
};

xhttp.open("GET", "./is-bitcoin-volatile", true);
xhttp.send();
