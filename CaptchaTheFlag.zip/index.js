let express = require('express');
let cookieParser = require('cookie-parser');
let bodyParser = require('body-parser');
const { createCanvas } = require("canvas");
const captcha = require("./captcha");
let app = express();
let PORT = 8000 || process.env.PORT;
let captchaCode;

app.use(bodyParser.urlencoded({ extended: false }))
app.use(cookieParser());

app.get("/", (req, res) => {
    const { image, text } = captcha(200, 200);
    captchaCode = text;
    res.send(
        `
        <title>Captcha The Flag</title>
        <img class="generated-captcha" src="${image}">
        <form method='POST' action='/check-code'>
            Captcha Value: <input type='text' name='captcha'/>
            <br/>
            Passcode (3 digit integer): <input type='password' name='code'/>
            <br/>
            <input type='submit'/>
        </form>
		<script>
		window.addEventListener( "pageshow", function ( event ) {
		  var historyTraversal = event.persisted || 
								 ( typeof window.performance != "undefined" && 
									  window.performance.navigation.type === 2 );
		  if ( historyTraversal ) {
			// Handle page restore.
			window.location.reload();
		  }
		});
		</script>
        `
    );
});

app.post('/check-code', (req, res) => {
    if(captchaCode === req.body.captcha && parseInt(req.body.code) === 726){
        res.send('pekoe{chamomile_mango_cef460}');
    }
    else if(captchaCode !== req.body.captcha){
        res.send('Incorrect captcha');
    }
    else if(parseInt(req.body.code) !== 726){
        res.send('Incorrect passcode');
    }
    else{
        res.send('Incorrect captcha or passcode');
    }
});

// Captcha generation, returns PNG data URL and validation text
app.get("/captcha/:width?/:height?/", (req, res) => {
    const width = parseInt(req.params.width) || 200;
    const height = parseInt(req.params.height) || 100;
    const { image, text } = captcha(width, height);
    res.send({ image, text });
});

module.exports = app;

app.listen(
    PORT,
    () => {
        console.log(`Running on port ${PORT}`);
    }
);